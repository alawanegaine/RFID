# RFID
Project de deux étutiants en PeiP1 Polytech'Tours durant l'année 2014-2015.

L'objectif de ce programme est d'automatiser l'émargement des étudiants pour savoir si ils sont présents durant certaines périodes grâce à leur carte étudiante.

## Utilisation
Vous trouvez des information sur l'utilisation du logiciel sur [le wiki](https://github.com/MrCraftCod/RFID/wiki).

## ??
![Diagramme](http://puu.sh/gSY2o/17f2a931a4.png)
